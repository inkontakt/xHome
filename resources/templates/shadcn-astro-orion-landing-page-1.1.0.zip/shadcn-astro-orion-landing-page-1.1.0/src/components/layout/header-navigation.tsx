'use client'

import { useEffect, useState, type ReactNode } from 'react'

import { ChevronRightIcon, CircleSmallIcon, MenuIcon } from 'lucide-react'

import { useActiveSection } from '@/hooks/use-active-section'
import { useMedia } from '@/hooks/use-media'

import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle
} from '@/components/ui/navigation-menu'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet'
import { SecondaryOrionButton } from '@/components/ui/orion-button'

import Logo from '@/components/logo'

import { cn } from '@/lib/utils'

type NavigationSection = {
  type: 'section'
  title: string
  items: NavigationItem[]
}

type NavigationItem = {
  title: string
  href: string
  icon?: ReactNode
  badge?: ReactNode
  description?: string
}

type Navigation = {
  title: string
  contentClassName?: string
} & (
  | {
      items: NavigationSection[]
      splitItems: true
      href?: never
    }
  | {
      items: NavigationItem[]
      splitItems?: never | false
      href?: never
    }
  | {
      items?: never
      splitItems?: never
      href: string
    }
)

const ListItem = (props: {
  title: NavigationItem['title']
  href: NavigationItem['href']
  icon?: NavigationItem['icon']
  badge?: NavigationItem['badge']
  description?: NavigationItem['description']
  splitItems?: boolean
  activeSection?: string
  pathname?: string
}) => {
  const { title, href, icon, badge, description, splitItems, activeSection, pathname } = props

  // Extract section id from href (e.g., '#home' -> 'home')
  const sectionId = href.startsWith('/#') ? href.slice(2) : href.startsWith('#') ? href.slice(1) : ''
  const isActive = sectionId ? activeSection === sectionId : pathname?.startsWith(href)

  return (
    <li className={cn({ 'group/link h-19.5': description && splitItems })}>
      <NavigationMenuLink
        href={href}
        data-active={isActive}
        className={cn({ 'flex flex-row items-start gap-2': icon })}
        asChild
      >
        <a href={href}>
          {icon && (
            <span className='bg-popover [&>svg]:text-popover-foreground! flex aspect-square size-7.5 shrink-0 items-center justify-center rounded-sm border [&>svg]:size-4.5!'>
              {icon}
            </span>
          )}
          {description ? (
            <div className='space-y-1'>
              <div className={cn('font-medium', { 'flex items-center gap-1.5': badge })}>
                {title}
                {badge}
              </div>
              <p className='text-muted-foreground group-hover/link:text-accent-foreground line-clamp-2 group-hover/link:opacity-70'>
                {description}
              </p>
            </div>
          ) : (
            <div className={cn('font-medium', { 'flex items-center gap-1.5': badge })}>
              {title}
              {badge}
            </div>
          )}
        </a>
      </NavigationMenuLink>
    </li>
  )
}

const HeaderNavigation = ({
  navigationData,
  navigationClassName,
  pathname = '/'
}: {
  navigationData: Navigation[]
  navigationClassName?: string
  pathname?: string
}) => {
  // Extract all section IDs from navigation data
  const sectionIds = navigationData.flatMap(navItem => {
    if (navItem.href) {
      const id = navItem.href.startsWith('/#')
        ? navItem.href.slice(2)
        : navItem.href.startsWith('#')
          ? navItem.href.slice(1)
          : ''

      return id ? [id] : []
    }

    if (navItem.items) {
      if (navItem.splitItems) {
        return navItem.items.flatMap(section =>
          section.items
            .map(item => {
              const id = item.href.startsWith('/#')
                ? item.href.slice(2)
                : item.href.startsWith('#')
                  ? item.href.slice(1)
                  : ''

              return id
            })
            .filter(Boolean)
        )
      }

      return navItem.items
        .map(item => {
          const id = item.href.startsWith('/#')
            ? item.href.slice(2)
            : item.href.startsWith('#')
              ? item.href.slice(1)
              : ''

          return id
        })
        .filter(Boolean)
    }

    return []
  })

  const activeSection = useActiveSection(sectionIds)

  return (
    <NavigationMenu viewport={false} className={cn('hidden lg:block', navigationClassName)}>
      <NavigationMenuList className='flex-wrap gap-0'>
        {navigationData.map(navItem => {
          if (navItem.href) {
            // Root link item
            const sectionId = navItem.href.startsWith('/#')
              ? navItem.href.slice(2)
              : navItem.href.startsWith('#')
                ? navItem.href.slice(1)
                : ''

            const isActive = sectionId ? activeSection === sectionId : pathname?.startsWith(navItem.href)

            return (
              <NavigationMenuItem key={navItem.title}>
                <NavigationMenuLink
                  href={navItem.href}
                  className={cn(
                    navigationMenuTriggerStyle(),
                    'text-muted-foreground hover:text-primary focus:text-primary bg-transparent px-3 py-1.5 text-base hover:bg-transparent focus:bg-transparent',
                    {
                      'text-primary font-medium': isActive
                    }
                  )}
                  asChild
                >
                  <a href={navItem.href}>{navItem.title}</a>
                </NavigationMenuLink>
              </NavigationMenuItem>
            )
          }

          // Section with dropdown
          // Check if any child item is active
          let hasActiveChild = false

          if (navItem.items) {
            if (navItem.splitItems) {
              hasActiveChild = navItem.items.some(section =>
                section.items.some(item => {
                  const id = item.href.startsWith('/#')
                    ? item.href.slice(2)
                    : item.href.startsWith('#')
                      ? item.href.slice(1)
                      : ''

                  return id && activeSection === id
                })
              )
            } else {
              hasActiveChild = navItem.items.some(item => {
                const id = item.href.startsWith('/#')
                  ? item.href.slice(2)
                  : item.href.startsWith('#')
                    ? item.href.slice(1)
                    : ''

                return id && activeSection === id
              })
            }
          }

          return (
            <NavigationMenuItem key={navItem.title}>
              <NavigationMenuTrigger
                className={cn(
                  'text-muted-foreground hover:text-primary focus:text-primary data-[state=open]:text-primary data-[state=open]:focus:text-primary data-[state=open]:hover:text-primary bg-transparent px-3 py-1.5 text-base hover:bg-transparent focus:bg-transparent data-[state=open]:bg-transparent data-[state=open]:hover:bg-transparent data-[state=open]:focus:bg-transparent [&_svg]:ml-2 [&_svg]:size-4',
                  {
                    'text-primary font-medium': hasActiveChild
                  }
                )}
              >
                {navItem.title}
              </NavigationMenuTrigger>
              <NavigationMenuContent className='absolute left-1/2 w-auto -translate-x-1/2 shadow-lg!'>
                {navItem.splitItems ? (
                  <div className={cn('grid grid-cols-1 gap-2', navItem.contentClassName)}>
                    {navItem.items.map(section => (
                      <div key={section.title} className='grid grid-cols-1 gap-3'>
                        <div className='text-muted-foreground px-2 text-sm'>{section.title}</div>
                        <ul
                          className={cn('grid grid-cols-1 gap-0.5', {
                            'gap-3': section.items.find(item => item.description)
                          })}
                        >
                          {section.items.map((item, index) => (
                            <ListItem
                              key={index}
                              icon={item.icon}
                              title={item.title}
                              description={item.description}
                              href={item.href}
                              badge={item.badge}
                              splitItems={navItem.splitItems}
                              activeSection={activeSection}
                            />
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                ) : (
                  <ul
                    className={cn(
                      'grid grid-cols-1 gap-0.5',
                      { 'gap-2': navItem.items?.find(item => item.description) },
                      navItem.contentClassName
                    )}
                  >
                    {navItem.items?.map((item, index) => (
                      <ListItem
                        key={index}
                        icon={item.icon}
                        title={item.title}
                        description={item.description}
                        href={item.href}
                        badge={item.badge}
                        activeSection={activeSection}
                        pathname={pathname}
                      />
                    ))}
                  </ul>
                )}
              </NavigationMenuContent>
            </NavigationMenuItem>
          )
        })}
      </NavigationMenuList>
    </NavigationMenu>
  )
}

const HeaderNavigationSmallScreen = ({
  navigationData,
  triggerClassName,
  screenSize = 1023,
  pathname = '/'
}: {
  navigationData: Navigation[]
  triggerClassName?: string
  screenSize?: number
  pathname?: string
}) => {
  const [open, setOpen] = useState(false)
  const isMobile = useMedia(`(max-width: ${screenSize}px)`, false)

  // Extract all section IDs from navigation data
  const sectionIds = navigationData.flatMap(navItem => {
    if (navItem.href) {
      const id = navItem.href.startsWith('/#')
        ? navItem.href.slice(2)
        : navItem.href.startsWith('#')
          ? navItem.href.slice(1)
          : ''

      return id ? [id] : []
    }

    if (navItem.items) {
      if (navItem.splitItems) {
        return navItem.items.flatMap(section =>
          section.items
            .map(item => {
              const id = item.href.startsWith('/#')
                ? item.href.slice(2)
                : item.href.startsWith('#')
                  ? item.href.slice(1)
                  : ''

              return id
            })
            .filter(Boolean)
        )
      }

      return navItem.items
        .map(item => {
          const id = item.href.startsWith('/#')
            ? item.href.slice(2)
            : item.href.startsWith('#')
              ? item.href.slice(1)
              : ''

          return id
        })
        .filter(Boolean)
    }

    return []
  })

  const activeSection = useActiveSection(sectionIds)

  const handleLinkClick = () => {
    setOpen(false)
  }

  useEffect(() => {
    if (!isMobile) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setOpen(false)
    }
  }, [isMobile])

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <SecondaryOrionButton size='icon-lg' className={cn('inline-flex lg:hidden', triggerClassName)}>
          <MenuIcon />
          <span className='sr-only'>Menu</span>
        </SecondaryOrionButton>
      </SheetTrigger>
      <SheetContent side='left' className='w-75 gap-0 p-0'>
        <SheetHeader className='p-4'>
          <SheetTitle hidden />
          <SheetDescription hidden />
          <a href='#' onClick={handleLinkClick} className='self-start'>
            <Logo />
          </a>
        </SheetHeader>
        <div className='space-y-0.5 overflow-y-auto p-2'>
          {navigationData.map((navItem, index) => {
            if (navItem.href) {
              const sectionId = navItem.href.startsWith('/#')
                ? navItem.href.slice(2)
                : navItem.href.startsWith('#')
                  ? navItem.href.slice(1)
                  : ''

              const isActive = sectionId ? activeSection === sectionId : pathname?.startsWith(navItem.href)

              return (
                <a
                  key={navItem.title}
                  href={navItem.href}
                  data-active={isActive}
                  className='hover:bg-accent data-[active=true]:bg-accent flex items-center gap-2 rounded-sm px-3 py-2 text-sm data-[active=true]:font-medium'
                  onClick={handleLinkClick}
                >
                  {navItem.title}
                </a>
              )
            }

            // Check if any child item is active
            let hasActiveChild = false

            if (navItem.items) {
              if (navItem.splitItems) {
                hasActiveChild = navItem.items.some(section =>
                  section.items.some(item => {
                    const id = item.href.startsWith('/#')
                      ? item.href.slice(2)
                      : item.href.startsWith('#')
                        ? item.href.slice(1)
                        : ''

                    return id && activeSection === id
                  })
                )
              } else {
                hasActiveChild = navItem.items.some(item => {
                  const id = item.href.startsWith('/#')
                    ? item.href.slice(2)
                    : item.href.startsWith('#')
                      ? item.href.slice(1)
                      : ''

                  return id && activeSection === id
                })
              }
            }

            return (
              <Collapsible key={index} className='w-full'>
                <CollapsibleTrigger
                  data-active={hasActiveChild}
                  className='hover:bg-accent group data-[active=true]:bg-accent flex w-full items-center justify-between rounded-sm px-3 py-2 text-sm data-[active=true]:font-medium'
                >
                  <div className='flex items-center gap-2'>{navItem.title}</div>
                  <ChevronRightIcon className='size-4 shrink-0 transition-transform duration-300 group-data-[state=open]:rotate-90' />
                </CollapsibleTrigger>
                <CollapsibleContent className='data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down overflow-hidden transition-all duration-300'>
                  {navItem.splitItems
                    ? navItem.items.map((item, i) => (
                        <div key={i} className='mt-1.5'>
                          <div className='text-muted-foreground mb-1 pl-4.5 text-xs font-medium'>{item.title}</div>
                          {item.items.map((subItem, j) => {
                            const sectionId = subItem.href.startsWith('/#')
                              ? subItem.href.slice(2)
                              : subItem.href.startsWith('#')
                                ? subItem.href.slice(1)
                                : ''

                            const isActive = sectionId
                              ? activeSection === sectionId
                              : pathname?.startsWith(subItem.href)

                            return (
                              <a
                                key={j}
                                href={subItem.href}
                                data-active={isActive}
                                className='hover:bg-accent data-[active=true]:text-primary ml-4.5 flex items-center gap-2 rounded-sm px-3 py-2 text-sm data-[active=true]:font-medium'
                                onClick={handleLinkClick}
                              >
                                {subItem.icon ? subItem.icon : <CircleSmallIcon className='size-4' />}
                                {subItem.title}
                              </a>
                            )
                          })}
                        </div>
                      ))
                    : navItem.items?.map(item => {
                        const sectionId = item.href.startsWith('/#')
                          ? item.href.slice(2)
                          : item.href.startsWith('#')
                            ? item.href.slice(1)
                            : ''

                        const isActive = sectionId ? activeSection === sectionId : pathname?.startsWith(item.href)

                        return (
                          <a
                            key={item.title}
                            href={item.href}
                            data-active={isActive}
                            className='hover:bg-accent data-[active=true]:text-primary ml-3 flex items-center gap-2 rounded-sm px-3 py-2 text-sm data-[active=true]:font-medium'
                            onClick={handleLinkClick}
                          >
                            {item.icon ? item.icon : <CircleSmallIcon className='size-4' />}
                            {item.title}
                          </a>
                        )
                      })}
                </CollapsibleContent>
              </Collapsible>
            )
          })}
        </div>
      </SheetContent>
    </Sheet>
  )
}

export { HeaderNavigation, HeaderNavigationSmallScreen, type Navigation, type NavigationItem, type NavigationSection }
