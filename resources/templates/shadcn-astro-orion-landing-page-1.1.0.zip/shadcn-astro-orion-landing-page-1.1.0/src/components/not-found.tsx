import { SecondaryOrionButton } from '@/components/ui/orion-button'

import Icon404 from '@/assets/svg/404'

const NotFound = () => {
  return (
    <div className='flex h-screen flex-col items-center justify-center gap-9 p-6'>
      <Icon404 className='h-auto w-full sm:h-120 sm:w-146' />
      <div className='flex flex-col items-center gap-4 text-center'>
        <p className='text-muted-foreground text-xl sm:text-2xl'>We couldn&apos;t find the page you are looking for</p>
        <SecondaryOrionButton size='lg' asChild>
          <a href='/'>Go back to home</a>
        </SecondaryOrionButton>
      </div>
    </div>
  )
}

export default NotFound
